# SYNC_AND_DATA_CONTRACT — Smart Dictation Player v0.0.6.t

Everything that touches bytes on a student's phone, or a byte on GitHub, is
specified here. If code and this document disagree, the document wins and the
code is the bug.

---

## R1 — Version and cache constants

| Constant | Value | Where |
| --- | --- | --- |
| `APP_VERSION` / `SDP.version` | `0.0.3` | `index.html` (`TARGET`), every module |
| `ver` | `12` | `data/version.json`, `data/config.json`, `data/elevenlabs-audio.json` |
| `schema` | `12` | same |
| `settingsRev` | `20` | same, and `SETTINGS_REV` in `data/sdp-data-sync.js:17` |
| `syncRev` | `1793654400000` | identical in version/config/voice-pack; seed for `nextSyncRev()` |
| `SW_VERSION` | `sdp-v0.0.3` | `sw.js` |
| `SHELL_CACHE` | `sdp-v0.0.3-shell` | `sw.js` |
| `PRESERVE_CACHES` | `['sdp-youdao-v1', 'sdp-audio-clips']` | `sw.js` |

There is exactly one version file: `data/version.json`. Never a root `/version.json`.

---

## R2 — `window.SDP` boot and reconciliation

```
boot()  →  GET ./data/version.json?t=<ms>   (cache: no-store)
        →  GET ./data/config.json?t=<ms>
        →  GET ./data/session.json?t=<ms>
        →  applyPayloads()  →  30 normalised words  →  'sdp:ready'
```

A hung request is finished by a 6,000 ms guard, so an offline phone never freezes
on the splash. `state.source` is `network`, `offline` or `memory`; the data toast
uses it (`Loaded · N KB` vs `Offline ready · 0 KB`).

`checkForUpdates(cb)` re-reads `version.json` and compares three fields:

| Field | Meaning | Effect when changed |
| --- | --- | --- |
| `session` | active session number | re-fetch `session.json`, swap the word bank |
| `settingsRev` | settings schema revision | re-fetch `config.json` |
| `syncRev` | monotonic publish stamp | re-fetch `session.json` |

`cb(null, {updated:true, session})` fires at most once per check. **It never
writes `sdp.progress`**, which is why a session published by the lecturer cannot
erase a student's streak (G8).

The watch runs `checkForUpdates` every 120,000 ms and on `visibilitychange`
(foreground). Tests set `window.__SDP_NO_LIVE__ = true` to stay offline.

---

## R3 — `data/version.json` (H3)

```json
{
  "ver": 12,
  "appVersion": "0.0.3",
  "version": "0.0.3",
  "buildDate": "2026-11-02",
  "schema": 12,
  "settingsRev": 20,
  "session": "8",
  "title": "Session 8 - Personal Feelings, Opinions & Experiences (Adj)",
  "updatedAt": "2026-11-02T09:58:11.030Z",
  "syncRev": 1793654400000
}
```

Ceiling 2,000 B. Anything larger means someone pasted the old multi-hundred-field
pointer file back in.

---

## R4 — `localStorage`: five keys, and only five (R8)

| Key | Shape |
| --- | --- |
| `sdp.progress` | `{mastered:{}, attempts:{}, weakWords:[], streak:{count,lastDate}, history:[], lastScore:null}` |
| `sdp.settings` | `{mode:"paper", writeSecs:5, repeats:2, pauseSecs:1.5, autoAdvance:true, voiceSource:"auto", rate:0.95, volume:1, lang:"en", theme:"dark", guideAutoPlay:true, pacingPreset:"exam", voiceLock:"unified", hints:{…}, cuesSeen:{}, appliedSettingsRev:0, defaultsResetV001f:false, vaultLock:{…}}` — **`cuesSeen` lives inside this object** (v0.0.2.a), never a sixth key |
| `sdp.session` | `{sessionId:"8", index:0, mode:"paper", answers:{}, updatedAt:0}` — deleted on finish |
| `sdp.guide_seen` | `"0.0.2.a"` once the student closes `#guideModal` (a version stamp, so a new release re-opens it) |
| `sdp.migrated_from_legacy` | `"1"` after the one-time import |

**R4a — creator-side pointer keys (v0.0.6.r).** Two dot-namespaced mirrors and
one flat pointer ride OUTSIDE the five student keys: `sdp.briefing.meta`
(`{syncRev, voiceId, voiceName, weekStamp, at}` — the Studio's local
briefing-pack mirror) and `sdp.last_pack_syncrev` (a single number: the newest
voice-pack `syncRev` this device has already pulled, so `boot()` re-pulls the
pack only when `version.json` genuinely advanced). None of them ever holds
student answers or settings; `G9.5c` allows the flat pointer by name.

**Corruption policy.** `Data.read()` wraps `JSON.parse` in try/catch. A corrupt
value is removed and replaced by the schema default; boot never throws
(G3 covers this).

**One-time legacy import.** While `sdp.migrated_from_legacy !== '1'`,
`Data.migrateLegacyOnce()` reads `sdp.v57_secure_local`, `sdp.v56_audit_verified`
and `sdp.v55_guaranteed_device_sync` (names built by string concatenation so no
shipped byte ever writes them), copies `streak`, `weakWords`/`missedWords`,
`mastered` and `history` into `sdp.progress`, writes the flag and then **never
touches a legacy key again**.

`data-meter.js` keeps its own metering counters under `sdp.dataMeter.*`; they are
telemetry for the `/data` page, contain no student content, and are excluded from
the five-key rule.

---

## R5 — `SDP_ENC_V2` cross-device vault (frozen wire format)

Envelope:

```
"SDP_ENC_V2:" + base64( salt[16] || iv[12] || AES-GCM-256(ciphertext || tag) )
```

Key derivation:

```js
baseKey = await crypto.subtle.importKey('raw', utf8(pin), 'PBKDF2', false, ['deriveKey']);
key     = await crypto.subtle.deriveKey(
            { name: 'PBKDF2', salt, iterations: 250000, hash: 'SHA-256' },
            baseKey, { name: 'AES-GCM', length: 256 }, false, ['encrypt','decrypt']);
```

- Plaintext: UTF-8 JSON, e.g. `{"ghToken":"…","elevenKey":"…","gasUrl":"…","updatedAt":1762000000000}`.
- Minimum real envelope: **29 decoded bytes** (16 salt + 12 iv + 1 tag byte).
- `"SDP_ENC_V2:AAA="` (3 bytes) and anything shorter is an **unconfigured empty
  vault**: `decryptV2()` resolves `{empty:true}` instead of throwing.
- Wrong PIN rejects `{code:'bad_pin', triesLeft}`. Five consecutive failures
  reject `{code:'locked', retrySec:60}` and lock for 60,000 ms; a correct PIN
  during the lock is still refused.
- Unlocked secrets live only in `sessionStorage['sdp.studio.unlocked']` and are
  cleared by `Vault.clear()` / the studio lock button. They never reach
  `localStorage`, a cookie, or the DOM.

Test vector (G2): `encryptV2({elevenKey:'sk_test', ghToken:'ghp_demo'}, '78987898')`
must round-trip, must differ on every run (fresh salt/iv), and must decrypt to
the identical object.

---

## R6 — Service worker policy

| Request | Strategy | Cache |
| --- | --- | --- |
| `dict.youdao.com/dictvoice…`, `?audio=` | cache-first | `sdp-youdao-v1` |
| `assets/audio/session-w*`, `blob:`, `elevenlabs` | cache-first | `sdp-audio-clips` |
| `.woff2`, `.png`, `.svg`, `.ico`, `.webp`, `/assets/fonts/` | cache-first | `sdp-v0.0.1.b-shell` |
| navigations | network-first, 4,000 ms → cache → `./index.html` | shell |
| same-origin `.html/.json/.js/.css/.webmanifest`, `/data/` | network-first, 4,000 ms | shell |

`install` precaches: `./`, `./index.html`, `./assets/css/sdp-ui.css`, the six
`./data/*.js` modules, `./data/version.json`, `./data/config.json`,
`./data/session.json`, both fonts, `./manifest.webmanifest`, `./data.html`,
`./data/index.html` — then `skipWaiting()`. A `sdp:cache-words` message handler
caches the 30 word-audio URLs on demand (offline downloader); both preserved
audio caches survive every upgrade.

`activate` deletes every `sdp-*` cache that is not the shell cache or a preserved
cache, then `clients.claim()`.

---

## R7 — Publishing (Studio only)

Two paths, both while unlocked:

1. **GitHub Contents API** — `PUT /repos/{owner}/{repo}/contents/{path}` with
   `{message, content: base64(utf8(text)), branch:'main', sha?}`. `sha` comes
   from a prior `GET`. Owner/repo come from the preserved `config.json`
  (`dictationb1` / `dictationb1.github.io`). v0.0.7.d: the app is served from BOTH https://dictationb1.web.app/ (Firebase Hosting · primary) and the github.io mirror — the hostname ladder answers `dictationb1` on the mirror, and the config `repoContentsUrl` answers it on web.app, so publishing and raw reads never depend on the serving origin.
2. **GAS relay** — CORS-simple `POST` with `Content-Type: text/plain` body
   `{action, app:'sdp', ver:'0.0.1.d'}` (hard ceiling 600 B). **The PIN is never
   in the body** (W6/D-S9): it is verified inside the Apps Script, which is the
   only place it exists. Word publishing is chunked so every chunk stays under
   40,000 B.

### Sequential publisher (`SDP.Sync.publishFilesSequential`)

`Promise.all` over three PUTs is forbidden: GitHub rejects concurrent commits to
the same branch and the lecturer sees a half-published session.

1. One file at a time, in the order given by the caller.
2. Before **every** PUT, `getFileSha()` re-reads the current `sha` — a cached sha
   from two seconds ago is stale by the time the next file commits.
3. A `409` triggers exactly one retry with a fresh sha, then the file is reported
   as failed instead of silently skipped.
4. **`data/version.json` is always published last**, so no device can ever read a
   new version number pointing at a session that has not landed yet.
5. `onFileStatus(path, ok, err)` paints progress; the callback returns
   `{ok, published, failed[], order[]}`.

Publishing writes `data/session.json`, `data/config.json`,
`data/elevenlabs-audio.json` and finally `data/version.json`; the version bump
carries the new `syncRev`, which is exactly what `checkForUpdates` watches.

**Preserved-file rule.** A deliberate publish legitimately changes
`data/session.json`. When that happens, update the `BUDGET`/`EXACT`/`PRESERVED_SHA`
tables in `tests/check.cjs` **and** Appendix A below in the same commit, then
rerun G1. Never hand-edit the payload itself. `data/elevenlabs-audio.json` is
app-written since v0.0.1.d and is therefore budgeted, not hash-frozen (D-UI11).

---

## R8 — `data/config.json` preserved payload

Must keep, untouched: `credits`, `tts`, `voice`, `live` (ntfy state/community/inbox),
`repoOwner: "dictationb1"`, `repoName: "dictationb1.github.io"`,
`encVault: "SDP_ENC_V2:AAA="`, `defaults`, `classInfo`,
`voiceId: "XB0fDUnXU5powFXDhCwa"`, `voiceName: "Charlotte"`,
`modelId: "eleven_flash_v2_5"`.

Only `ver: 12`, `appVersion: "0.0.3"`, `version: "0.0.3"`, `schema: 12`,
`settingsRev: 20` are ours to change.

---

## Appendix A — Preservation locks (this release)

```
c96dbe6de02d7d6d6a1a92ac0409d2c1745f24629b8ae8375a2a88ad10651db9  data/session.json                 57,381 B
591b9b086f6d3723afb2604a837ffc495c69a481c490f11e58131c2222b0981e  data/gas-source.txt              13,764 B
23f1503e1e75413903dff05f4415f59d4b903cfeb2a8d1c0047ac158d20ff280  assets/fonts/NotoSansSinhala-Regular.woff2  48,520 B
bf59c1487b0a88a07a678190fd7a6e93aa01c5ec3f3f2f9e349922ac944a643e  assets/fonts/NotoSansSinhala-Bold.woff2     48,748 B
```

Verify at any time with:

```bash
shasum -a 256 -c /tmp/sdp-preserve.sha256   # phase manifest
node tests/check.cjs                        # G1, same table baked in
```

`data/elevenlabs-audio.json` left this table in v0.0.1.d: the Lecturer Studio
rewrites it on every publish, so a frozen hash was a publishing bug waiting to
happen. It is now capped at 2,500,000 B and its header (`version`, `appVersion`,
`ver`, `schema`, `voiceId`) is asserted by G1 and G9.6g.

`data/session.json` content contract: `lists[0]` = `list_session_8_feelings`
(30 words, `w/p/pos/m/si/s/audio`), `lists[1]` = `list_session_7_travel`
(30 archived words), plus `plan`, `session` metadata and `pastSessions`.

---

## Appendix B — Gate-to-contract map

| Gate | Contracts asserted |
| --- | --- |
| G1 | H1 budgets, W3 ES5, R9 byte-identical `/data`, Appendix A, retired ids |
| G2 | R1, R5 (vault), R4 (migration), R2 (reconciliation), R7 (payload shapes) |
| G3 | R4 (corruption + migration), R5 (PIN lockout), R2 (guide), R5/R6 grading, W7 (language purity) |
| G4 | Preserved Apps Script backend (`data/gas-source.txt`) — seven behaviour tests unchanged |
| G5 | R3 (header 54px, single screen), R4 (input law), R5 (ring colours), R9 (toast) |
| G6 | R6 (cache purge → `sdp-v0.0.1.b-shell`, preserved caches, single reload, offline shell) |
| G7 | R2 (journeys), R5 (self-check + retry), R4 (legacy migration), R8 (settings order) |
| G8 | R2 (two-device propagation without touching progress), R7 (publish) |
| G9 | R5 (audio tiers, beat text, one-utterance `say`, same-element replay) |
| G10 | R4 (one professor voice, male-name blacklist), R3 (Guide 2.0 step machine, 600 ms watchdog, `#guideTapBanner`) |
| G11 | R5 (`SDP_ENC_V2` 16B salt ‖ 12B iv, 250k PBKDF2), R6 (sequential publish, `version.json` last, fresh sha, one 409 retry), W6 (no PIN in any body or URL) |
| G12 | W5 (no gate touches the billing endpoint), R9 (EN + SI strings), studio widgets `#pinPad`/`#btnTestElKey`/`#btnTestGhToken`/`#btnCommitClip` |

---

## R11. Publish chunk budget is measured in BYTES

Apps Script cells are limited to 40,000 **bytes**, not characters. Sinhala is
three bytes per glyph in UTF-8, so a chunk that looks safe by `.length` can be
33% over budget. `Sync.publishWordsChunked` therefore accumulates
`utf8Encode(line).length` and closes a chunk before it would exceed the limit.
The regression test builds 300 Sinhala-heavy words and asserts every chunk is
under budget (`tests/upgrade.test.cjs`, "R7: GitHub Contents payload").

## R12. Five keys, no probe

The store layer must never write a key just to test writability. Capability is
detected by shape (`typeof localStorage.setItem === 'function'`); every write is
individually wrapped in `try/catch` and returns `false` on failure. `tests/audit-v42.cjs`
(G9.5c) and `tests/upgrade.test.cjs` (R1) both fail the build if a sixth key
appears in the source.

---

**Credits — preserved verbatim, EN and SI.**
`CREDITS GOES TO Hansana` ·
Lecturer in Charge: Ms. Sumodya Sewmini · Creator: Hansana · Concept: Ayya01 (Lesandu) ·
නිර්මාණය: Hansana · අදහස: Ayya01 (Lesandu) · භාරකාර කථිකාචාර්ය: Ms. Sumodya Sewmini

---

## R11 — v0.0.1.d: the guaranteed classroom settings contract

### R11.1 `config.classSettings` (the ten keys the lecturer owns)

```json
"classSettings": {
  "mode": "paper", "writeSecs": 8, "repeats": 3, "pauseSecs": 1.5,
  "autoAdvance": true, "pacingPreset": "standard", "voiceLock": "unified",
  "voiceSource": "auto", "rate": 0.95, "theme": "dark"
}
```

`SDP.Studio.saveClassSettings()` copies those ten keys out of
`SDP.Data.settings()`, bumps `settingsRev`, stamps `syncRev = Date.now()` and
commits `data/config.json` then `data/version.json` (always last) through
`SDP.Sync.publishFilesSequential`.

### R11.2 Adoption (SYNC-01, SYNC-02)

`sdp.settings.appliedSettingsRev` defaults to `0`. Whenever
`remote.settingsRev > appliedSettingsRev` — including the very first boot —
`SDP.Sync.adoptRemoteSettings()` copies the ten keys from `classSettings`
(falling back to `defaults`), **overrides `touchedKeys` for exactly those ten
keys**, clears them from `touchedKeys`, stores the new `appliedSettingsRev`,
calls `SDP.Engine.applySettings()` + `SDP.Views.renderAll()` and fires
`sdp:teacher-updated` (`{ settingsRev }`), which the UI shows as
`📡 Synced teacher's latest classroom settings (Rev #N)`.

Personal keys `lang`, `guideAutoPlay`, `volume`, `hints` and the whole
`sdp.progress` payload are never written by an adoption.

### R11.3 The 30 s pointer read (SYNC-05)

`SDP.Sync.startWatch(30000)` polls **only**
`https://raw.githubusercontent.com/dictationb1/dictationb1.github.io/main/data/version.json?t=…`
(falling back to `./data/version.json`). A full `checkForUpdates()` — the only
path that touches `api.github.com` — runs only when `syncRev`, `settingsRev` or
`appVersion` moved, on `visibilitychange`, on a manual `#syncBadge` tap, or
while the Studio resolves its vault envelope.

### R11.4 PIN gate (SEC-01..04)

`data/config.json` ships:

```json
"pinVerifier": { "algo": "PBKDF2-SHA256", "iterations": 250000, "salt": "…", "hash": "…" }
```

for the bootstrap lecturer PIN `78987898`. While locked, the Studio renders only
`#studioPin`, `#pinDots`, `#pinPad` (12 keys, 56 px), `#studioMsg` and the
ask-your-lecturer hint. When `encVault` is the placeholder `SDP_ENC_V2:AAA=`
the PIN is proved against `pinVerifier`; otherwise the real envelope is
decrypted with `Vault.decryptV2()`.

Brute force is bounded by `sdp.settings.vaultLock = { fails, lockUntil, strikes }`:
5 wrong attempts → 60,000 ms lock; a second offence (`strikes >= 2`) → 300,000
ms. The value lives in `localStorage`, so a reload never clears it.

### R11.5 Voice tiers (VOX-04, rewritten in v0.0.1.e by D10)

`voiceLock === 'unified'` (default) and `voiceSource !== 'custom'` →
`resolveTiers()` returns lecturer clip → Alice clip → **`neural_tts` only when a
verified Tier-1 Neural UK Female voice is present (score ≥ 100 and
`getVoices().length > 0`)** → dictionary (`dict.youdao.com` type=1, real human
British recording) → browser TTS **last**. v0.0.1.d excluded the dictionary tier
entirely and left Brave (0 voices) silent; the real human recording now always
precedes low-quality synth. Explicit `custom` keeps the d behaviour.

---

## R13 — v0.0.1.e: honest sync, migration and the one publish clock

### R13.1 Never-red dual-source version check (D1, D5, D17)

`checkForUpdates(cb)` reads `./data/version.json?t=<ms>` (same-origin, Source 1)
and, if that fails, `raw.githubusercontent.com/dictationb1/dictationb1.github.io/main/data/version.json`
(Source 2). **Either HTTP 200 resolves `cb(null, { ok: true, … })`; the badge
goes red only when both sources fail.** `api.github.com` is never polled by
students — it stays token-only Studio access. `cb(err, result)` fires exactly
once per check; one shared `Views.handleSyncCheckResult(err, result)` composes
the badge/toast, and the 30 s watch tick plus `visibilitychange` both feed it.

### R13.2 Service worker origin gate (D2)

The `fetch` handler's FIRST check is the origin: only same-origin requests and
`dict.youdao.com/dictvoice` audio are ever intercepted — everything else
(including `api.github.com` and `api.elevenlabs.io`) passes straight through.
Data reads (`data/*.json`): 10 s network-first with `cache: 'reload'`, a clean
path cache put (never a `?t=` URL), an `ignoreSearch` cache fallback, and an
honest 503 JSON offline page. `activate` purges retired `sdp-*` caches and every
stale `?t=` entry, preserving `sdp-youdao-v1` and `sdp-audio-clips`.

### R13.3 One-time language migration (D7, R3)

`defaultSettings().lang` is `'en'`. On boot, while `sdp.settings.langResetV001e`
is falsy, `Data.settings()` forces `lang: 'en'` once, sets
`langResetV001e: true` **inside** `sdp.settings` (never a sixth top-level key)
and persists. `lang` is NOT in `CLASS_SETTING_KEYS`: a student's later choice is
personal and survives every class-settings adoption.

### R13.4 One publish clock + coherent payloads (D13, D19)

`Studio.nextSyncRev()` = `Math.max(Date.now(), prevSyncRev + 1)`. Every file of
one publish (config, session, voice pack, version) carries the SAME stamp;
`version.json` is committed last via `publishFilesSequential`. `saveKeys()`
ALWAYS recomputes `config.pinVerifier` from the salt already published in
`config.json` (fresh 16-byte salt only when no verifier exists) — the verifier
can never go stale after a PIN change. `session.clips` (word→clip URLs) survive
`buildSessionPayload()`, and `Studio.publishChecklist()` refuses a publish whose
words, envelope, verifier or syncRev are incoherent — in plain language.

## §R12 — v0.0.1.f verified adoption, one clock and the third vault slot

### §R12.1 `SDP.Sync.fetchFreshDataJson(relPath, cb)`

```
fetchFreshDataJson('data/version.json', function (err, result) {
  // err   — only when BOTH sources failed (never a red screen for one blocked host)
  // result.ok        === true
  // result.json      — the winning payload
  // result.source    — 'origin' | 'raw'
});
```

Both legs start in parallel: same-origin `./<relPath>?t=<ms>` with `cache:'no-store'`
and a 6 s timeout, and `raw.githubusercontent.com/dictationb1/dictationb1.github.io/main/<relPath>`
with a 5 s timeout. The higher `payload.syncRev` wins; `raw` breaks an exact tie. A
failed leg can never win, so a Brave-Shields-blocked CDN still delivers the truth.

### §R12.2 Payload verification (the load-bearing rule)

For every publish tick, the winning `version.json` defines `targetSyncRev`. A payload
leg is usable only when `Number(json.syncRev) >= targetSyncRev`, **or** — for
`data/session.json` only — it is the preserved classroom baseline: same session number
as the pointer and ≥ 30 words. A leg that fails this test is refetched once from the
other source; if it still fails, the result is

```
{ ok: true, error: 'stale_payload', changed: false, updated: false,
  deferred: true, retry: ['data/config.json', ...] }
```

and `SDP.Sync.state.version` keeps pointing at the last fully delivered publish. The
next watch tick retries the same publish, so nothing is silently skipped. `ok:false` is
reserved for "both version sources are unreachable".

### §R12.3 Adoption chain and beat deferral

`applyPayloads(version, config, session)` → `adoptRemoteSettings(cfg, settingsRev)` →
`SDP.Speech.reloadManifest()` → `SDP.Views.renderAll()` (alias `refreshAll`). When
`SDP.Engine.isActive()` is true (`listening`/`writing`) the chain is queued and replayed
by `SDP.Sync.flushDeferred()` at the end of the beat, so a lecturer publish never cuts a
word off mid-speech. `sdp:update` is dispatched for anything that listens outside the
core (Home badge, preset pill, Studio).

### §R12.4 One publish clock (W8)

`nextSyncRev() = Math.max(Date.now(), previous + 1)` is called exactly once per publish
path (`publishBundle()`, `publishWordsAndVoice()`, `sealVaultNow()`-driven vault save,
`saveClassSettings()`). The same integer is stamped into `session.json`, `config.json`,
`elevenlabs-audio.json` and `version.json`; `version.json` is committed last by
`publishFilesSequential()`, so a device that reads a new pointer can always fetch bodies
that belong to it.

### §R12.5 Third vault slot (`aiKey` / `aiProvider`)

`SDP_ENC_V2` now seals three secrets: `elevenKey`, `ghToken` and the free-AI pair
`aiKey` + `aiProvider` (`free_dict` | `groq` | `gemini` | `openrouter`). Nothing new is
written to disk: the ciphertext still lives in `config.encVault` and the local cache
inside `sdp.settings.cachedVault`. `config.json` never carries a key — only the
envelope and `pinVerifier`.

### §R12.6 Free enrichment contract

`SDP.Studio.enrichWords(wordsOrText, opts, cb)`:

* `free_dict` (default, zero keys) → `api.dictionaryapi.dev` (`p`, `pos`, `m`, `s`) and
  `api.mymemory.translated.net?langpair=en|si` (`si`);
* `groq` / `gemini` / `openrouter` → one batch JSON call for the whole list, validated
  row by row;
* every path ends in the deterministic offline B1 lexicon, so a dead tower still
  yields a complete six-field record (`enrichSource:'lexicon'`);
* it never calls ElevenLabs — extraction and synthesis are separate concerns (W5).

### §R12.7 Defaults and the one-time migration

`lang:'en'`, `pacingPreset:'exam'`, `writeSecs:5`, `repeats:2`, `voiceLock:'unified'`,
`voiceSource:'auto'`, `rate:0.95`. On the first read after upgrading, `sdp.settings`
gains `defaultsResetV001f:true`, the seven defaults above are re-applied once and the
`touchedKeys` entries for `pacingPreset`/`writeSecs`/`repeats`/`voiceLock` are cleared.
No sixth localStorage key is ever created (W4).

---

## R13 — v0.0.1.h: Rule 1A, Rule 1B, Layer 1 and the session trap

### R13.1 Rule 1A — the key ladder (D1, D2)

`SDP.Studio.fetchSubscription(key, cb)` never invents a failure. Three rungs, in order:

1. `GET /v1/user/subscription` → 200 → the real quota (`{ok:true, remaining:(character_count,character_limit)}`).
2. Subscription refused (401/403/404/429) → probe `GET /v1/voices`. Anything 200 means the
   key is real but scoped → `{ok:true, scoped:true, remaining:null, note:SCOPED_NOTE}`.
3. Probe also failed → accept the key when `looksLikeElevenKey(key)` (format check only) →
   same scoped verdict, so a free-tier key on a locked-down network still gets green.

Only `detail.status === 'invalid_api_key'` (HTTP 401) is fatal, and it is the only path
that paints red. `quotaError()` translates every other status into a sentence a teacher
can act on; the literal string `subscription_failed` can never reach the DOM (G11.10d).

### R13.2 Rule 1B — one-click master setup (D3, D4)

```
step 1  merge inputs → sealVaultNow → writeLayerOne → testGitHubToken   ← the ONLY fatal step
step 2  checkQuota(elKey)                                              ← advisory, always proceeds
step 3  generateClips({force, noCommit:true})  guide 1–4 + up to 30 words
step 4  injectClips → publishBundle() → 4 files, ONE nextSyncRev(), version.json LAST
```

A 401/402/403/429 *inside* clip generation is a tier status, not an error: the clips
already produced are kept, the rest are marked skipped, `ST.tierWarn = TIER_WARN()` is
shown, and the run resolves into step 4 so the four files still publish (G11.11a–g).
`G11` also proves the paid endpoint is never called by a test — the stub answers any
`elevenlabs.io` URL that is not `/v1/user/subscription` or `/v1/voices`.

### R13.3 Layer 1 — the vault inside `sdp.settings` (D5, D8, D9)

`sdp.settings.vaultLock` is the second copy of the envelope: a **plain object** with
`{fails, lockUntil, strikes, until, encVault, pinVerifier, updatedAt}`. It is written by
`setup`, `saveKeys`, `unlock` (on success) and `writeLayerOne()`, and read by
`healFromLayerOne()` at boot, inside `resolveEnvelope()` and in `unlockWithVerifier()`.

Self-heal rule: when Layer 1 holds a real `SDP_ENC_V2:` envelope, its `updatedAt` is newer
than the config record, or the config record is the template placeholder
(`SDP_ENC_V2:AAA=`), then `encVault` + `pinVerifier` are copied into the config record and
the vault survives a release that reset `data/config.json`. Unlocking then decrypts the
healed envelope with the PIN, so `ST.secrets` is filled instead of `{}` (G11.12a–i).
Layer 1 is still *inside* `sdp.settings`: the five-key law in R4 is untouched (G11.12d).

### R13.4 Config-sovereign adoption (D15) and the session trap (D16, D17)

`settle()` weighs three legs. The session leg no longer has veto power:

* config verified → adopt `version.json` + `config.json`, apply `classSettings`, advance the
  pointer, and report `deferredSession:true` when the session leg failed;
* config failed → adopt nothing (`stale_payload`), so a half-published tree can never brick
  a device.

`verifyPayloadLeg('session')` accepts a payload that proves the pointer (`syncRev`), a
matching session number with at least one word (D16), or the same active list by
`id` + `words.length` + `updatedAt`. Because any of those proves the payload, a test that
wants a rejection must send a 0-word list or a different session number (G11.15a–d).

`needSession` is false only when the session number is unchanged **and** `payloadFiles`
names no session file (D17, legacy headers excluded) and no device state asked for a
retry. A settings-only publish therefore costs 3 small requests and never re-downloads the
57,381 B `data/session.json` (G11.13a–d). A device that lost its session still pulls it on
the next tick because `state.deferredSession` survives the adoption (G11.14c).

### R13.5 The publish contract did not move

`publishFilesSequential()` still does fresh SHA → PUT → await → next file with
`data/version.json` last and one `nextSyncRev() = max(Date.now(), prev+1)` across all four
files (G11.11c–e); a locked Studio still refuses to publish at all. v0.0.2.a adds no
second clock: the studio's delta retry (`queueFor(words, singleTest, keys)`) re-bills
nothing and re-publishes through the same single-clock path.

---

## R14 — v0.0.1.i: one clock, one retry, one honest sentence

### R14.1 D14/W8 — a publish has exactly one clock

`publishConfigAndVersion()` and `publishBundle()` each call `nextSyncRev()` **once**
(`data/studio.js:1661`, `:1687`); the value is stamped into `version.json`,
`config.json`, `session.json` and `elevenlabs-audio.json` before the first PUT. A second
call would move the pointer after the bodies were built, which is how two devices could
disagree about which release they had. G11 asserts the four bodies share one `syncRev`
(G11.11c–e); G2 asserts the shipped `syncRev` is above both payload clocks.

`nextSettingsRev()` stays `Math.max(schemaVer(), current + 1)` (`data/studio.js`), so
`settingsRev` only ever moves forward. Shipped value in v0.0.2.a: **16**; the module
constant `SETTINGS_REV` (`data/sdp-data-sync.js:17`) is **16** to match — they must never
disagree, or a device re-adopts stale `classSettings` (the D10 trap). They were 9 and 9 while
the data said 12 — that mismatch is what D10 allowed a device to "fix" by re-adopting
stale `classSettings`.

### R14.2 D10 — no release literal decides adoption

The v0.0.1.h clamp

```js
if (APP_VERSION === '0.0.1.h' && appliedRev > state.settingsRev && state.settingsRev === 8)
```

is gone. Adoption is monotonic in the payload itself (`data/sdp-data-sync.js:976`):
remote settings are adopted when the remote `settingsRev` is greater than the applied
one, whatever the release is called. A test fixture that pins its own
`appliedSettingsRev` must therefore pin **99**, not 7 or 8, or the adoption overwrites
it (G3.1j, G10.5a were both caught this way).

### R14.3 D11 — `stale_payload` is a report, not a verdict

When the session leg fails but config + version verified, `settle()` still adopts the
config and the callback receives:

```js
{ ok:false, error:'stale_payload', changed:true, updated:true, deferred:true,
  deferredSession:true, retry:['data/session.json'], session, settingsRev,
  appVersion, source, payloadSources, chain }
```

So "the teacher's settings landed" and "the session is stale" are both true at once
(G11.14a–c). `ok:false` keeps the retry queued; `changed:true` is what repaints the UI.
Adopting nothing is reserved for a failed **config** leg, which is the only way a
half-published tree could brick a device.

### R14.4 D7 — every failure is one sentence

`SDP.Sync.publishErrorText(status, ghMsg)` (`data/sdp-data-sync.js:1430`) maps
401 → expired token, 403 → no permission, 404 → repo/path missing, 409 → conflict
retried, 422 → rejected payload, 5xx → GitHub trouble, status 0 → offline, and appends
GitHub's own `message` when the API supplied one. The Studio wraps it with the clock:
`"Publish failed · hhmm · reason"` (`data/studio.js:1974`, `:1989`). No raw code and no
`rev N` may appear on a failed publish (G12.13k–n).

### R14.5 D16 — one retry, fresh SHA, and only once

`publishFilesSequential(files, token, onFileStatus, cb, opts)` retries a failed PUT
**once** when the status is `0` or `>= 500`, after `opts.retryDelayMs` (default
2,000 ms, gates pass 50 ms) and after re-reading the SHA — never with the stale one.
A 409 keeps its own single fresh-SHA retry and does not consume the network retry
(G11.3a–b, G11.11c–e). If the retry also fails the publish ends `publish_partial` with
`.reason`, `.status` and `.errors`, and the files already committed stay committed.

### R14.6 D17/D5/D6 — the checklist and the failure strings

`publishChecklist(payloads, opts)` (`data/studio.js:1873`) requires a real
`config.encVault` and `config.pinVerifier` **only** when the device has a vault
(`hasVault()`); a keys-less bundle publishes without them and warns instead of failing.
When it does fail, each step reports its own sentence from `publishReason()`
(`data/studio.js:1979`) — never a shared "failed" — and `clearBusy()` (`:1994`) clears
`generating`/`publishing`/`enriching` on every exit (G12.13j, G12.13p).

---

## R15 — v0.0.2.a: UI state that must never become a sixth key

v0.0.2.a moved a lot of pixels without moving a byte of student data.

| New UI state | Where it lives | Why it is safe |
| --- | --- | --- |
| `cuesSeen` (which amber `.cue` the student has already acted on) | inside `sdp.settings` | a sixth localStorage key would break R8; a malformed value is healed to `{}` on read (`sdp-data-sync.js:196`) |
| `#sessionPills` done/current/todo | DOM only | repainted from `E.items` + `E.index` on every tick; never persisted |
| `pendingGen`, `lastFailedClip`, `genProgress` | `SDP.Studio.state` (memory) | a failed clip is retried with a fresh request, never resumed from a stale pointer |
| `#studioPackDashboard` X/70 | computed by `clipCount()` | counts only keys that `clipExists()`; never a cached number |
| `#resumeBanner` | `sdp.session` draft | `{index, repeatsDone, remainingMs, pausedPhase, pauseReason}` — the same draft R5 already guarantees |
| `guide_seen` stamp | `sdp.guide_seen` | still one of the five keys; value is the release string `0.0.3` |

The publish order is unchanged: `session.json → config.json → elevenlabs-audio.json →
version.json`, one `syncRev` for all four, `version.json` last. A locked studio or a
token-less studio still commits nothing.


## R-AUDIO-NORM — v0.0.6.v client-side broadcast normalizer (`data/sdp-audio-normalize.js`)

`window.SDP.AudioNormalize` (strict ES5) ships RBJ biquad generators (high-shelf +4 dB @ 1500 Hz, high-pass 38 Hz, peaking +2.5 dB @ 3000 Hz Q 0.9) with **all coefficients divided by a0**, `measureLoudness` implementing **BS.1770-4** (400 ms blocks, 75% overlap / 100 ms hop, two-stage gating at -70 LUFS absolute then -10 dB relative), `normalizeSamples` (presence shelf -> linear gain to the signature target -> tanh soft-limit at truePeakMax), `normalizeTake(arrayBuffer, signature, cb)` returning a 16-bit PCM WAV `ArrayBuffer`, plus `measureBuffer` and `encodeWav`. Studio `requestClip()` runs every `words.*` / `num.*` take through it (the `_intro_male_*` beats and `cmd.*` reference are NEVER re-normalized); fallback takes (attempt >= 1) are stamped `degradedTake: true` and paint an amber ⚠ badge in the clip table.

## R-TELEMETRY — v0.0.6.v cross-device telemetry ledger (`data/sdp-telemetry.js`)

`window.SDP.Telemetry` (strict ES5, no `.padStart()`) keeps a persistent `clientId` (`sdp_u_<16-hex>` via `('0' + n.toString(16)).slice(-2)`), `visitCount`, `totalDwellSec`, an **append-only** `sessions[]` and `incidents[]` — all nested inside `sdp.settings.telemetry` (the five-key law holds). `pushTelemetryEnvelope()` POSTs `text/plain` to `https://ntfy.sh/sdp_<owner>_telemetry_v1` and the GAS `telemetry_sync` action; `pullTelemetryLedger()` reads `…/json?poll=1&since=all` (3.5 s timeout) plus GAS `telemetry_pull` and merges into `sdp.settings.telemetryLedger`. No IP, no raw user-agent, no free text leaves the client.

## R-SELFHEAL — v0.0.6.v student self-heal assistant (`data/sdp-selfheal.js`)

`window.SDP.SelfHeal` owns `#sdpSelfHealModal` and the seven triggers: **T1** manifest load timeout/abort, **T2** `MEDIA_ERR_SRC_NOT_SUPPORTED/_DECODE/_NETWORK` on a word clip, **T3** tier fall-through reaching `tts`, **T4** long-frame lag (3 rAF deltas > 250 ms within 10 s), **T5** SW version mismatch (a waiting worker), **T6** localStorage quota failure, **T7** extension interference (dark-mode/translate meta). Each surfaces the exact plain-English copy with 1-tap actions (Reload Voice Clips, Switch to Backup Audio, Refresh Page, Clear Old Audio), deduped per trigger-type per session and re-armed after 5 minutes, and logs an incident through `SDP.Telemetry.recordIncident(...)`.

## R-V006V — v0.0.6.v origin, briefing and pack laws

- **Dynamic origin derivation**: `Sync.repoFromOrigin()` reads the serving `hostname` first (`owner.github.io`), then `cfg.repoContentsUrl`, then the config fallback; `fetchRawMainJson` retries once from the re-derived hostname on 404/error (logging `sync_origin_healed`).
- **Briefing escape hatch**: `#btnBriefingSkipTop` (never disabled) closes the briefing immediately; both `beat1Guard` failsafes are 9000 ms; the gate timer pauses while `document.hidden`; `briefingContentHash` (inside `sdp.settings`) exempts returning students from version-bump replays when the content is unchanged.
- **Pack law**: `data/elevenlabs-audio.json` ships exactly **74 clips** (30 active `words.*` + 30 `num.1..30` + 6 `cmd.*` + 4 `guide.en.*` + 4 `_intro_male_1..4`), raw JSON <= 4,500,000 B, `wordsRev` stamped on every publish, and `purgeStaleBriefingClips({ words: true })` clears non-active `words.*` entries from `sdp-audio-clips` and `state.clipBase` whenever `wordsRev` advances.


## §R-V006W — v0.0.6.w release laws (ver 37 / schema 37 / settingsRev 61 / syncRev 1797000000010 / SW sdp-v0.0.6.w-s36)

1. **No-boot-briefing** — boot never opens #briefingModal;
   `openBriefing({replay:true, fromSettings:true})` opens #briefingStage
   directly with all exits unlocked and narrates from Paragraph 1 Word 1.
2. **Never-quarantine** — `verifyBritishRPWord` never sets quarantined during
   `generateClips`; every new word synthesizes via `buildFallbackRpHint(w)`
   (rpSource 'fallback') when the lexicon/dictionary/AI legs miss.
3. **Pure-MP3 law** — `requestClip` stores the genuine audio/mpeg MP3 bytes;
   `measureBuffer` only MEASURES (lufs/truePeakDbTp/gainLinear metadata); the
   speech layer auto-detects UklGR (audio/wav) vs MP3 on hydration and applies
   clip.gainLinear at playback.
4. **Unified cloned voice** — see ARCHITECTURE_MAP §R-UNIFIED-CLONED-VOICE.
5. **Live Lab** — lab.html + data/sdp-live-lab.js (see §R-LIVE-LAB); both are
   registered in the H1 budgets and the ES5 gate.

## §R-V006X — the v0.0.6.x voice-engine laws

1. **R-V006X-1 CLEAN-WORD TTS LAW** — `buildQueue()`/`requestClip()` speak the
   clean British orthography (`item.text`); only curated `RP_TTS_OVERRIDES`
   heterophones may be respelled. `ttsHint` and IPA `p` are display-only.
2. **R-V006X-2 BROADCAST FORMAT LAW** — every non-timestamped TTS request
   appends `?output_format=mp3_44100_128`.
3. **R-V006X-3 74-CLIP PACK LAW** — the shipped pack carries exactly the 74
   canonical clips (30 words.* + 30 num.* + 6 cmd.* + 4 guide.en.* +
   4 _intro_male_*), every classroom take MP3 3:1:9:0:3 at -21.0 LUFS.
4. **R-V006X-4 STALE-CLIP LAW** — `purgeStaleWordsFromPack()` gates
   `voicePackPayload()`/`commitVoicePack()`; `applyManifest()` drops old
   `words.*` keys when `wordsRev` advances; `#btnForceRegenWords` wipes and
   re-synthesizes the 30 active words.
5. **R-V006X-5 UNIFIED VOICE CENTER** — `#studioCardClassroomVoice` is the
   single Voice & Clone Control Center; the briefing card lives in the
   Advanced drawer with every DOM id intact.
6. **R-V006X-6 LIVE LAB v2.0** — `lab.html` boots ALL PASS (0 FAIL); all
   stations live inside the IIFE; `labKey()` never reads localStorage;
   Station 3 carries the 1-click batch word repair tool.

Version pins for this release: ver 38, schema 38, settingsRev 62,
syncRev/wordsRev 1797000000011, SW `sdp-v0.0.6.x-s37`.
