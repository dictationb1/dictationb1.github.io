SMART DICTATION PLAYER — v0.0.7.h RELEASE PACK
=================================================
The Live Lab Station 8 Interactive Verification Release: Apps Script Relay +
Access Lock + Password + Telegram, 1-Tap Force Update, Stale-Cache
Auto-Eviction.

CONTENTS
  sdp-v0.0.7.h/            the complete committed source tree at the release
                           commit (git archive — no git metadata). Deploy by
                           pushing this tree to the dictationb1.github.io
                           repository (or Firebase Hosting: firebase.json is
                           included and pre-configured).
  VERIFICATION-v0.0.7.h/   the final outputs of all 30 gate suites
                           (G1..G29 + briefing-feedback-lab — 100% PASS,
                           0 FAIL) and LOCKSTEP-MANIFEST.txt (sizes +
                           SHA-256 of every shipped file).

WHAT'S NEW IN v0.0.7.h (see docs/CHANGELOG_LEDGER.md §v0.0.7.h)
  1. STATION 8 (Live Lab) — 8 live probes against YOUR real Apps Script
     /exec URL: version & cache, URL & deployment, ping + auto-sheet health
     + the 5 Script Property badges, admin PIN auth, password unlock
     (verify_lock_secret), single-use burnable code round-trip with
     2nd-device REJECTION, student access_request -> access_decision ->
     check_device firstGrant token, Telegram webhook + phone alert. Every
     probe paints the exact raw response + a bilingual EN/SI fix; the
     report is redacted (PINs, passwords, tokens, deployment IDs stripped).
     The Admin PIN lives ONLY in page memory.
  2. BUG-H1 (stale service worker) — sw.js s47: 3 s NETWORK_TIMEOUT_FAST
     for the critical shell, skipWaiting + clients.claim, older sdp-*-shell
     caches auto-deleted; the Instant Version Mismatch Detector paints the
     red "Force Update Now" banner in the Studio and lab.html — 1 tap
     unregisters the old worker, purges the stale cache and reloads.
  3. BUG-H2 — data/config.json accessLock.relayUrl pre-wires the verified
     /exec relay URL, so Station 8 and the Access Lock work out of the box.
  4. Backend (gas-source.txt, gas v0.0.7.h) — new admin actions
     tg_webhook_info (server-side Telegram getWebhookInfo; the bot token
     never crosses the browser) and lab_test_cleanup (removes the
     synthetic Station 8 test devices + burned code row).
  5. Session-14 repair — the owner-publish regression that dropped
     "mobile phone"'s pronunciationVariants is fixed (RP variants restored).
  6. Unified lockstep — ver/schema 48, settingsRev 83, syncRev+wordsRev
     1797000000032, SESSION_BYTES 63086, new G29 gate registered in
     check.cjs TEST_FILES, tests/package.json gates and checks.yml.

DEPLOY (owner)
  1. Push the sdp-v0.0.7.h/ tree to the dictationb1.github.io repo main.
  2. Open the Apps Script project, replace ALL code with
     data/gas-source.txt, save, Deploy -> Manage deployments -> Edit ->
     Version: New version -> Deploy (Access: Anyone).
  3. Verify Script Properties exist: ADMIN_PIN, TG_BOT_TOKEN, TG_CHAT_ID,
     TG_WEBHOOK_SECRET (LOCK_HMAC_SECRET optional).
  4. Open https://dictationb1.github.io/lab.html -> Station 8: the /exec
     URL pre-fills from config.json; type the Admin PIN, run, expect
     8 PASS. Then GitHub Actions runs all 30 gates green on the push.

$0 open-source system · CCBE Galle Branch B1 English Class
Lecturer in Charge: Ms. Sumodya Sewmini · Creator: Hansana · Concept: Ayya01 (Lesandu)
